#ifndef NOODKNOP_H
#define NOODKNOP_H

#include <avr/io.h>
#define Noodknop PC1

int isNoodknopIngedrukt(void);

#endif // NOODKNOP_H
